package itunes

import android.os.Parcel
import android.os.Parcelable

data class ItunesWrapper(var resultCount: Int, var results: List<ResultData>)

data class ResultData(
                var trackName: String? = "",
                var collectionName: String? = "",
                var artworkUrl30: String? = "",
                var trackViewUrl: String? = "") : Parcelable {

    constructor(parcel: Parcel) : this(
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString()
    ) {
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(trackName)
        parcel.writeString(collectionName)
        parcel.writeString(artworkUrl30)
        parcel.writeString(trackViewUrl)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<ResultData> {
        override fun createFromParcel(parcel: Parcel): ResultData {
            return ResultData(parcel)
        }

        override fun newArray(size: Int): Array<ResultData?> {
            return arrayOfNulls(size)
        }
    }


}
