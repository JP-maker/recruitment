package com.jpcarraze

import itunes.ItunesWrapper
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface ItunesService {

    @GET("search")
    fun getMusics(@Query("term") textSearch: String,
                  @Query("media") typeSearch: String = "music") : Call<ItunesWrapper>
}