package com.jpcarraze

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import itunes.ResultData
import kotlinx.android.synthetic.main.item_music.view.*

class MusicsAdapter(val musicsSearchResult: List<ResultData>, val itemClickListener: View.OnClickListener)
    : RecyclerView.Adapter<MusicsAdapter.ViewHolder>() {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val cardView = itemView.card_view as CardView
        val icon = itemView.image_music as ImageView
        val music = itemView.title_music as TextView
        val album = itemView.album_music as TextView
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val viewItem = inflater.inflate(R.layout.item_music, parent, false)
        return ViewHolder(viewItem)
    }

    override fun getItemCount(): Int {
        return musicsSearchResult.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val currentItem = musicsSearchResult[position]
        Picasso.get()
            .load(currentItem.artworkUrl30)
            .placeholder(R.mipmap.ic_launcher)
            .into(holder.icon)
        holder.music.text = currentItem.trackName
        holder.album.text = currentItem.collectionName
        holder.cardView.tag = position
        holder.cardView.setOnClickListener(itemClickListener)
    }
}