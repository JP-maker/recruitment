package com.jpcarraze

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import itunes.ItunesWrapper
import itunes.ResultData
import okhttp3.OkHttpClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


class MainActivity : AppCompatActivity(), View.OnClickListener {

    // Declaration des variables pour le listing
    lateinit var resultsItems: MutableList<ResultData>
    lateinit var adapter : MusicsAdapter

    private val httpClient = OkHttpClient.Builder()
        .build()


    //Déclaration pour le paramétrage de base de la requette http
    private val retrofit = Retrofit.Builder()
        .client(httpClient)
        .baseUrl("https://itunes.apple.com/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    // On passe le formatage désiré
    private val itunesService : ItunesService = retrofit.create(ItunesService::class.java)

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialisation du RecycleView
        resultsItems = mutableListOf<ResultData>()
        adapter = MusicsAdapter(resultsItems, this)
        val recyclerView = findViewById<RecyclerView>(R.id.musics_recycle_view) as RecyclerView
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
        recyclerView.setHasFixedSize(true)

        findViewById<Button>(R.id.btn_search).setOnClickListener { startSearch() }

    }

    // Onclick du Recycler View : On ouvre un webbrowser avec le lien du titre
    override fun onClick(view: View) {
        if (view.tag != null) {
            val openURL = Intent(android.content.Intent.ACTION_VIEW)
            openURL.data = Uri.parse(resultsItems[view.tag as Int].trackViewUrl.toString())
            startActivity(openURL)
        }
    }

    // On lance la requette sur Itunes et met à jour le listing
    private fun startSearch() {

        val textSearch = findViewById<EditText>(R.id.inputTextSearch).text.toString()
        val call = itunesService.getMusics(textSearch)

        call.enqueue(object: Callback<ItunesWrapper> {

            override fun onResponse(call: Call<ItunesWrapper>, response: Response<ItunesWrapper>) {

                if (response.body()?.results != null){
                    resultsItems.clear()
                    resultsItems.addAll(response.body()!!.results)
                    adapter.notifyDataSetChanged()
                }

            }

            override fun onFailure(call: Call<ItunesWrapper>, t: Throwable) {
                Log.i("mainActivity", "Could not load result of your search", t)
            }
        })
    }

    private fun changeText() {
        adapter.notifyDataSetChanged()
    }
}


